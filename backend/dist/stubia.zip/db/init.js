"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.initDatabase = initDatabase;
const child_process_1 = require("child_process");
const index_1 = __importDefault(require("./index"));
const seed_1 = require("./seed");
async function initDatabase() {
    console.log("[DB Init] Menjalankan migrasi database otomatis...");
    try {
        // Menjalankan 'npx prisma migrate deploy'
        // Menggunakan npx agar kompatibel baik di Windows (pengembangan lokal) maupun Linux (Hostinger)
        (0, child_process_1.execSync)("npx prisma migrate deploy", { stdio: "inherit" });
        console.log("[DB Init] Migrasi database berhasil diselesaikan.");
    }
    catch (err) {
        console.error("[DB Init] Gagal menjalankan migrasi database:", err);
        // Kita tetap melanjutkan startup agar aplikasi tidak mati total jika ada masalah koneksi sementara
    }
    try {
        console.log("[DB Init] Memeriksa apakah database memerlukan seeding...");
        const userCount = await index_1.default.user.count();
        if (userCount === 0) {
            console.log("[DB Init] Database kosong. Menjalankan seeding...");
            await (0, seed_1.seedDatabase)();
            console.log("[DB Init] Seeding database berhasil diselesaikan.");
        }
        else {
            console.log("[DB Init] Database sudah terisi data. Seeding dilewati.");
        }
    }
    catch (err) {
        console.error("[DB Init] Gagal menjalankan seeding database:", err);
    }
}
//# sourceMappingURL=init.js.map